Contributing guidelines
=======================

This document only redirects to more `detailed instructions <https://giotto-ai.github.io/gtda-docs/latest/contributing>`_,
which consist of:

- a pull request checklist,
- a Contributor License Agreement,
- contributing guidelines and standards, including coding style guides.
