The following is the list of code authors of the ``giotto-tda`` python package.

Where component authors are known, add them here.

| Guillaume Tauzin, gtauzin@protonmail.com
| Umberto Lupo, umberto.lupo@epfl.ch
| Lewis Tunstall, lewis.c.tunstall@gmail.com
| Matteo Caorsi, m.caorsi@l2f.ch
| Philippe Nguyen, p.nguyen@l2f.ch
| Julian Burella Pérez, julian.burellaperez@heig-vd.ch
| Alessio Ghiraldello, amg28@protonmail.com
| Adélie Garin, adelie.garin@epfl.ch
| Anibal Medina-Mardones, anibal.medinamardones@epfl.ch
| Wojciech Reise, reisewojciech@gmail.com
| Roman Yurchak, roman.yurchak@symerio.com
| Nick Sale, nicholas.j.sale@gmail.com
| Rayna Andreeva, r.andreeva@sms.ed.ac.uk
