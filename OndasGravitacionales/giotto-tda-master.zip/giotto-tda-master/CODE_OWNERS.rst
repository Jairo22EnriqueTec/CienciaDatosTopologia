The following is the list of code owners of the ``giotto-tda`` Python package:

- L2F SA
- EPFL - Ecole Polytechnique Fédérale de Lausanne
- REDS Institute of the Haut Ecole d'Ingénierie et Gestion du canton Vaud
