########################
Giotto-TDA documentation
########################

********
Contents
********

.. toctree::
   :maxdepth: 2

   library
   installation
   modules/index
   notebooks/index
   theory/glossary
   contributing/index
   release
   faq
