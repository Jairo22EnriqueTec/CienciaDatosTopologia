:mod:`gtda.metaestimators`: Meta-estimators
===========================================

.. automodule:: gtda.metaestimators
   :no-members:
   :no-inherited-members:

.. currentmodule:: gtda

.. autosummary::
   :toctree: generated/base/
   :template: class.rst

   metaestimators.CollectionTransformer
