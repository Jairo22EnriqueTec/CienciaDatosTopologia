:mod:`gtda.point_clouds`: Point clouds
==========================================

.. automodule:: gtda.point_clouds
   :no-members:
   :no-inherited-members:

.. currentmodule:: gtda

.. autosummary::
   :toctree: generated/
   :template: class.rst

   point_clouds.ConsistentRescaling
   point_clouds.ConsecutiveRescaling