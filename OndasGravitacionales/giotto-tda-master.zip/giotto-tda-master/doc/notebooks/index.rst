######################
Tutorials and examples
######################

.. image:: ../images/tda_logo.svg
   :width: 850

.. _notebooks_index:

Browse through our tutorials to get acquainted with ``giotto-tda``'s API and basic functionality. Check out the
examples for more in-depth applications.

.. toctree::
   :maxdepth: 2

   tutorials
   examples



