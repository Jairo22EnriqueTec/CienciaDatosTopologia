{{objname}}
{{ underline }}====================

.. currentmodule:: {{module}}

.. autofunction:: {{objname}}

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: {{module}}.{{objname}}.examples

.. raw:: html

    <div class="clearer"></div>
