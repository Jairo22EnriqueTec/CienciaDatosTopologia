This file describe the governance of the giotto-tda project.

Project owner:
--------------

- L2F SA

Authors:
--------

- Please refer to the `authors <https://github.com/giotto-ai/giotto-tda/blob/master/CODE_AUTHORS>`_ file

Giotto-tda Project Team:
------------------------

- Umberto Lupo umberto.lupo@epfl.ch (Maintainer)
- Wojciech Reise reisewojtus@gmail.com (Maintainer)
- Matteo Caorsi m.caorsi@l2f.ch (Project Leader)

Former Project Team Members:
----------------------------

- Lewis Tunstall lewis.c.tunstall@gmail.com (Maintainer)
- Philippe Nguyen p.nguyen@l2f.ch (Developer)
